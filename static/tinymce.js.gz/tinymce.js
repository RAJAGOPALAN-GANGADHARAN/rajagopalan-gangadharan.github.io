tinyMCE.init({
      mode : "textareas",
      theme : "advanced",
      force_br_newlines : false,
      force_p_newlines : false,
      forced_root_block : '',
  });